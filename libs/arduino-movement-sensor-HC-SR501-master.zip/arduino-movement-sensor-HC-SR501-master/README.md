# arduino-movement-sensor-HC-SR501
Using movement sensor HC-SR501 with arduino and relay (for example, to control light)
