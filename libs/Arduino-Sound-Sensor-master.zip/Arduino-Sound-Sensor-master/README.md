# Arduino
Soundsensor - how to read from a analogue sound sensor and display on an OLED screen.
			  Uses A0 as input from an analogue mic, Tested on Arduino Nano V3.
			  Please download library for OLED here: https://github.com/olikraus/u8glib/wiki/device
			  
			  Pin mapping
			  OLED SDA - Arduino A4			 
			  OLED SLC - Arduino A5
			  OLED VCC - Arduino 5V
			  OLED GND - Arduino GND
			  Mic A - Arduino A0
			  Mic + - Arduino 3V3
			  Mic - - Arduino GND