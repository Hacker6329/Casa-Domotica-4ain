## Upload arduino code

upload the vibration.ino to arduino

## Install Packages

Run `npm install`

## Start node ap

Run `node vibration.js`  to listen to arduino on serialport ( change /dev/cu.usbmodem1411 to appropriate device )

