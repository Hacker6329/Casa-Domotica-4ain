TCRT5000/TCRT5000L library for Arduino
==================

Features:
 - Only checks for digital proximity. Nothing sophisticated. 
 - If you connect a second pin to IR-diode, it will blink for 100us, thus drain less power.

License
==================

This code is licensed under [CC BY-SA 3.0]( https://creativecommons.org/licenses/by-sa/3.0/ ).

Other Things
==================
 - My Twitter: [@cediddi](http://twitter.com/cediddi)
 - [My Blog](http://blog.umutkarci.com)

Special Thanks To
==================
 - [Javier Rodrigo](https://github.com/JRodrigoTech) for his Ultrasonic library (gave me the inspiration)
